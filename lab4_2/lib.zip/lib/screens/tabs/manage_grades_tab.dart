import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ManageGradesTab extends StatefulWidget {
  const ManageGradesTab({super.key});
  @override
  State<ManageGradesTab> createState() => _ManageGradesTabState();
}

class _ManageGradesTabState extends State<ManageGradesTab> {
  final studentId = TextEditingController();
  final subject = TextEditingController();
  final mid = TextEditingController();
  final fin = TextEditingController();

  Future<void> _addOrUpdate() async {
    final sid = studentId.text.trim();
    final sub = subject.text.trim();
    if (sid.isEmpty || sub.isEmpty) return;

    // id = sid_sub để update dễ
    final docId = '${sid}_$sub';
    await FirebaseFirestore.instance.collection('grades').doc(docId).set({
      'studentId': sid,
      'subject': sub,
      'scoreMid': double.tryParse(mid.text.trim()) ?? 0,
      'scoreFinal': double.tryParse(fin.text.trim()) ?? 0,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  @override
  Widget build(BuildContext context) {
    final q = FirebaseFirestore.instance
        .collection('grades')
        .orderBy('updatedAt', descending: true)
        .limit(100);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              TextField(
                controller: studentId,
                decoration: const InputDecoration(labelText: 'Mã học sinh'),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: subject,
                decoration: const InputDecoration(labelText: 'Môn học'),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: mid,
                      decoration: const InputDecoration(labelText: 'Giữa kỳ'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: fin,
                      decoration: const InputDecoration(labelText: 'Cuối kỳ'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: _addOrUpdate,
                child: const Text('Lưu điểm'),
              ),
            ],
          ),
        ),
        const Divider(height: 0),
        Expanded(
          child: StreamBuilder(
            stream: q.snapshots(),
            builder: (context, snap) {
              if (!snap.hasData)
                return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;

              return ListView.builder(
                itemCount: docs.length,
                itemBuilder: (_, i) {
                  final d = docs[i].data();
                  return ListTile(
                    title: Text('${d['studentId']} • ${d['subject']}'),
                    subtitle: Text(
                      'GK: ${d['scoreMid']} • CK: ${d['scoreFinal']}',
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => docs[i].reference.delete(),
                    ),
                    onTap: () {
                      studentId.text = d['studentId'] ?? '';
                      subject.text = d['subject'] ?? '';
                      mid.text = (d['scoreMid'] ?? 0).toString();
                      fin.text = (d['scoreFinal'] ?? 0).toString();
                    },
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    studentId.dispose();
    subject.dispose();
    mid.dispose();
    fin.dispose();
    super.dispose();
  }
}
