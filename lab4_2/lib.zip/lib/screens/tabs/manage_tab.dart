import 'package:flutter/material.dart';
import 'manage_announcements_tab.dart';
import 'manage_grades_tab.dart';

class ManageTab extends StatelessWidget {
  const ManageTab({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: const TabBar(
          tabs: [
            Tab(icon: Icon(Icons.campaign), text: 'Thông báo'),
            Tab(icon: Icon(Icons.school), text: 'Điểm'),
          ],
        ),
        body: const TabBarView(
          children: [ManageAnnouncementsTab(), ManageGradesTab()],
        ),
      ),
    );
  }
}
